# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.autograd as autograd

import copy
import numpy as np

from domainbed import networks
from domainbed.lib.misc import random_pairs_of_minibatches

if torch.cuda.is_available():
    device = "cuda"
else:
    device = "cpu"
criterionCEre = nn.CrossEntropyLoss(reduce=False)

ALGORITHMS = [
    'ERM',
    'ACE'
]

def get_algorithm_class(algorithm_name):
    """Return the algorithm class with the given name."""
    if algorithm_name not in globals():
        raise NotImplementedError("Algorithm not found: {}".format(algorithm_name))
    return globals()[algorithm_name]


class Algorithm(torch.nn.Module):
    """
    A subclass of Algorithm implements a domain generalization algorithm.
    Subclasses should implement the following:
    - update()
    - predict()
    """
    def __init__(self, input_shape, num_classes, num_domains, hparams):
        super(Algorithm, self).__init__()
        self.hparams = hparams

    def update(self, minibatches):
        """
        Perform one update step, given a list of (x, y) tuples for all
        environments.
        """
        raise NotImplementedError

    def predict(self, x):
        raise NotImplementedError

class ERM(Algorithm):
    """
    Empirical Risk Minimization (ERM)
    """

    def __init__(self, input_shape, num_classes, num_domains, hparams):
        super(ERM, self).__init__(input_shape, num_classes, num_domains,
                                  hparams)
        self.featurizer = networks.Featurizer(input_shape, self.hparams)
        self.classifier = networks.Classifier(
             self.featurizer.n_outputs,
             num_classes,
             self.hparams['nonlinear_classifier'])
        self.network = nn.Sequential(self.featurizer, self.classifier)
        self.optimizer = torch.optim.Adam(
            self.network.parameters(),
            lr=self.hparams["lr"],
            weight_decay=self.hparams['weight_decay']
        )

    def update(self, minibatches):
        all_x = torch.stack([x for x,y in minibatches])
        all_y = torch.cat([y for x,y in minibatches])
        loss = F.cross_entropy(self.predict(all_x), all_y)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return {'loss': loss.item()}

    def predict(self, x):
        return self.network(x)


class ACE(ERM):
    """
    Perform ERM while matching the pair-wise domain feature distributions
    using MMD (abstract class)
    """
    def __init__(self, input_shape, num_classes, num_domains, hparams):
        super(ACE, self).__init__(input_shape, num_classes, num_domains,
                                  hparams)
        
        self.num_classes = num_classes

    def update(self, minibatches):
        objective = 0
        penalty = 0

        data_list = [xi for xi, _ in minibatches]
        target_list = [yi for _, yi in minibatches]
        data = torch.stack(data_list,0)
        target = torch.tensor(target_list).to(device)
        bs = int(data.shape[0] / 3)
        
        triplefeatures = self.featurizer(data)
        tripleoutput = self.classifier(triplefeatures)
        
        objective = F.cross_entropy(tripleoutput, target)
        
        penalty = self.contrastive_ace(2, self.classifier, triplefeatures, target, self.num_classes, bs)
        
        self.optimizer.zero_grad()
        (objective + (self.hparams['mmd_gamma']*penalty)).backward()
        self.optimizer.step()
        
        if torch.is_tensor(penalty):
            penalty = penalty.item()

        return {'loss': objective.item(), 'penalty': penalty}
    

    def ACE(self, featureidx, numsamples, classifier, feature, targetm, outdim):
        bs, zdim = feature.shape
        zdo = torch.randn(numsamples, bs, zdim).to(device)
        zdo[:,:,featureidx] = feature[:,featureidx]
        sample = classifier(zdo.view(numsamples*bs, zdim))
        ACEdo = sample.view(numsamples, bs, -1).mean(0)

        zrand=torch.randn(numsamples, bs, zdim).to(device)
        sample=classifier(zrand.view(numsamples*bs, zdim))
        ACEbaseline = sample.view(numsamples, bs, -1).mean(0)
        ace = ACEbaseline - ACEdo
        
        return(ace)


    def contrastive_ace(self, numsamples, classifier, feature, targetm, outdim, anchorbs):
        numfeature = feature.shape[1]
        ace = []
        for i in range(numfeature):
            ace.append(self.ACE(i, numsamples, classifier, feature, targetm, outdim))
        
        acematrix = torch.stack(ace,dim=1) / (torch.stack(ace,dim=1).norm(dim=1).unsqueeze(1) +1e-8)  # [bs, num_feature]
        anchor = acematrix[:anchorbs] / acematrix[:anchorbs].norm(1)
        neighbor = acematrix[anchorbs:2*anchorbs] / acematrix[anchorbs:2*anchorbs].norm(1)
        distant = acematrix[2*anchorbs:] / acematrix[2*anchorbs:].norm(1)
        
        margin = 0.02
        pos = (torch.abs(anchor - neighbor)).sum()
        neg = (torch.abs(anchor - distant)).sum()
        contrastive_loss = F.relu(pos - neg + margin)
        
        return contrastive_loss