import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'

import argparse
import collections
import json

import random
import sys
import time
import uuid

import numpy as np
import PIL
import torch
import torchvision
import torch.utils.data

from domainbed import datasets
from domainbed import hparams_registry
from domainbed import algorithms
from domainbed.lib import misc
from domainbed.lib.fast_data_loader import InfiniteDataLoader, FastDataLoader

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Domain generalization')
    parser.add_argument('--data_dir', type=str, default="/mnt/nfsdisk/domaindata/")

    parser.add_argument('--dataset', type=str, default="PACS")

    parser.add_argument('--algorithm', type=str, default="ACE")

    parser.add_argument('--hparams', type=str,
        help='JSON-serialized hparams dict')
    parser.add_argument('--hparams_seed', type=int, default=0,
        help='Seed for random hparams (0 means "default hparams")')

    parser.add_argument('--trial_seed', type=int,                default=1,
        help='Trial number (used for seeding split_dataset and '
        'random_hparams).')
    parser.add_argument('--seed', type=int, default=  0,
        help='Seed for everything else')

    parser.add_argument('--steps', type=int, default=None,
        help='Number of steps. Default is dataset-dependent.')

    parser.add_argument('--checkpoint_freq', type=int, default=300,
        help='Checkpoint every N steps. Default is dataset-dependent.')



    parser.add_argument('--test_envs', type=int, nargs='+',  default=[0])

    parser.add_argument('--output_dir', type=str, default="train_output")
    parser.add_argument('--holdout_fraction', type=float, default=0.2)
    parser.add_argument('--skip_model_save', action='store_true')
    args = parser.parse_args()

    # If we ever want to implement checkpointing, just persist these values
    # every once in a while, and then load them from disk here.
    start_step = 0
    algorithm_dict = None

    os.makedirs(args.output_dir, exist_ok=True)
    sys.stdout = misc.Tee(os.path.join(args.output_dir, 'out.txt'))
    sys.stderr = misc.Tee(os.path.join(args.output_dir, 'err.txt'))

    print("Environment:")
    print("\tPython: {}".format(sys.version.split(" ")[0]))
    print("\tPyTorch: {}".format(torch.__version__))
    print("\tTorchvision: {}".format(torchvision.__version__))
    print("\tCUDA: {}".format(torch.version.cuda))
    print("\tCUDNN: {}".format(torch.backends.cudnn.version()))
    print("\tNumPy: {}".format(np.__version__))
    print("\tPIL: {}".format(PIL.__version__))

    print('Args:')
    for k, v in sorted(vars(args).items()):
        print('\t{}: {}'.format(k, v))

    if args.hparams_seed == 0:
        hparams = hparams_registry.default_hparams(args.algorithm, args.dataset)
    else:
        hparams = hparams_registry.random_hparams(args.algorithm, args.dataset,
            misc.seed_hash(args.hparams_seed, args.trial_seed))
    if args.hparams:
        hparams.update(json.loads(args.hparams))

    print('HParams:')
    for k, v in sorted(hparams.items()):
        print('\t{}: {}'.format(k, v))

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    if torch.cuda.is_available():
        device = "cuda"
    else:
        device = "cpu"

    if args.dataset in vars(datasets):
        dataset = vars(datasets)[args.dataset](args.data_dir,
            args.test_envs, hparams)
    else:
        raise NotImplementedError

    # Split each env into an 'in-split' and an 'out-split'. We'll train on
    # each in-split except the test envs, and evaluate on all splits.
    in_splits = []
    out_splits = []
    for env_i, env in enumerate(dataset):
        out, in_ = misc.split_dataset(env,
            int(len(env)*args.holdout_fraction),
            misc.seed_hash(args.trial_seed, env_i))
        if hparams['class_balanced']:
            in_weights = misc.make_weights_for_balanced_classes(in_)
            out_weights = misc.make_weights_for_balanced_classes(out)
        else:
            in_weights, out_weights = None, None
        in_splits.append((in_, in_weights))
        out_splits.append((out, out_weights))

    class_specific_test_dataset = []
    for i in range(dataset.num_classes):
        class_specific_test_dataset.append([])
    print('          num classes :     {}'.format(dataset.num_classes))

    for domain_index in range(4):
        if domain_index in args.test_envs:
            print('test domain : {}'.format(domain_index))
            for sample_index in range(len(in_splits[domain_index][0])):
                data = in_splits[domain_index][0][sample_index][0]
                target = in_splits[domain_index][0][sample_index][1]
                class_specific_test_dataset[target].append([data, target])
    torch.save(class_specific_test_dataset, 'class_specific_test_dataset-pacs0.pt')
    print(' =========== class-specific-test-dataset finished ============ ')


    class_specific_train_dataset = []
    for i in range(dataset.num_classes):
        class_specific_train_dataset.append([])
    print('          num classes :     {}'.format(dataset.num_classes))

    for domain_index in range(4):
        if domain_index not in args.test_envs:
            print('domain{}'.format(domain_index))
            for sample_index in range(len(in_splits[domain_index][0])):
                # print('sample{}'.format(sample_index))
                data = in_splits[domain_index][0][sample_index][0]
                target = in_splits[domain_index][0][sample_index][1]
                class_specific_train_dataset[target].append([data, target])


    train_loaders = [InfiniteDataLoader(
        dataset=env,
        weights=env_weights,
        batch_size=hparams['batch_size'],
        num_workers=dataset.N_WORKERS)
        for i, (env, env_weights) in enumerate(in_splits)
        if i not in args.test_envs]

    eval_loaders = [FastDataLoader(
        dataset=env,
        batch_size=hparams['batch_size'],
        num_workers=dataset.N_WORKERS)
        for env, _ in (in_splits + out_splits)]
    eval_weights = [None for _, weights in (in_splits + out_splits)]
    eval_loader_names = ['env{}_in'.format(i)
        for i in range(len(in_splits))]
    eval_loader_names += ['env{}_out'.format(i)
        for i in range(len(out_splits))]

    algorithm_class = algorithms.get_algorithm_class(args.algorithm)
    algorithm = algorithm_class(dataset.input_shape, dataset.num_classes,
        len(dataset) - len(args.test_envs), hparams)

    if algorithm_dict is not None:
        algorithm.load_state_dict(algorithm_dict)

    algorithm.to(device)

    train_minibatches_iterator = zip(*train_loaders)
    checkpoint_vals = collections.defaultdict(lambda: [])

    steps_per_epoch = min([len(env)/hparams['batch_size'] for env,_ in in_splits])

    n_steps = args.steps or dataset.N_STEPS
    checkpoint_freq = args.checkpoint_freq or dataset.CHECKPOINT_FREQ
    print('--------------- checkpoint freq ---------------')
    print(checkpoint_freq)

    last_results_keys = None
    for step in range(start_step, n_steps):
        step_start_time = time.time()
        minibatches_device = [(x.to(device), y.to(device))
            for x,y in next(train_minibatches_iterator)]

        neighbour_list = []
        distant_list = []
        label_dist_list = []

        anchor_data = minibatches_device[0][0]
        anchor_label = minibatches_device[0][1]
        bs = anchor_data.shape[0]
        for ibatch in range(bs):
            neighbour_label = anchor_label[ibatch]
            neighbour_idx = np.random.randint( len(class_specific_train_dataset[neighbour_label]) , size=1)[0]
            neighbour = class_specific_train_dataset[neighbour_label][neighbour_idx][0]
            distant_label = np.random.randint(dataset.num_classes, size=1)[0]
            while distant_label == anchor_label[ibatch]:
                distant_label = np.random.randint(dataset.num_classes, size=1)[0]
            distant_idx = np.random.randint( len(class_specific_train_dataset[distant_label]) , size=1)[0]
            distant = class_specific_train_dataset[distant_label][distant_idx][0]

            label_dist_list.append(distant_label)
            neighbour_list.append(neighbour)
            distant_list.append(distant)

        neighbour_batch   = torch.stack(neighbour_list,0).to(device)
        distant_batch     = torch.stack(distant_list,0).to(device)
        label_dist_list   = torch.tensor(label_dist_list).to(device)

        triplet_minibatches_device = []
        for i in range(bs):
            triplet_minibatches_device.append([anchor_data[i].to(device),torch.tensor([anchor_label[i]]).to(device)])
        for i in range(bs):
            triplet_minibatches_device.append([neighbour_batch[i].to(device),torch.tensor([anchor_label[i]]).to(device)])
        for i in range(bs):
            triplet_minibatches_device.append([distant_batch[i].to(device),torch.tensor([label_dist_list[i]]).to(device)])

        step_vals = algorithm.update(triplet_minibatches_device)
        checkpoint_vals['step_time'].append(time.time() - step_start_time)

        for key, val in step_vals.items():
            checkpoint_vals[key].append(val)

        if step % checkpoint_freq == 0:
            results = {
                'step': step,
                'epoch': step / steps_per_epoch,
            }

            for key, val in checkpoint_vals.items():
                results[key] = np.mean(val)

            evals = zip(eval_loader_names, eval_loaders, eval_weights)
            for name, loader, weights in evals:
                acc = misc.accuracy(algorithm, loader, weights, device)
                results[name+'_acc'] = acc

            results_keys = sorted(results.keys())
            if results_keys != last_results_keys:
                misc.print_row(results_keys, colwidth=12)
                last_results_keys = results_keys
            misc.print_row([results[key] for key in results_keys],
                colwidth=12)

            results.update({
                'hparams': hparams,
                'args': vars(args)    
            })

            epochs_path = os.path.join(args.output_dir, 'results.jsonl')
            with open(epochs_path, 'a') as f:
                f.write(json.dumps(results, sort_keys=True) + "\n")

            algorithm_dict = algorithm.state_dict()
            start_step = step + 1
            checkpoint_vals = collections.defaultdict(lambda: [])

            save_dict = {
                "args": vars(args),
                "model_input_shape": dataset.input_shape,
                "model_num_classes": dataset.num_classes,
                "model_num_domains": len(dataset) - len(args.test_envs),
                "model_hparams": hparams,
                "model_dict": algorithm.state_dict()
            }

    with open(os.path.join(args.output_dir, 'done'), 'w') as f:
        f.write('done')
